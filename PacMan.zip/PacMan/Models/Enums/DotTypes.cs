﻿namespace PacMan.Models.Enums
{
    public enum DotTypes
    {
        NotSet = 0,
        Regular,
        Heavy,
    }
}
