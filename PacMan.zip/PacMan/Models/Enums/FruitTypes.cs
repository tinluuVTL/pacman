﻿namespace PacMan.Models.Enums
{
    public enum FruitTypes
    {
        NotSet = 0,
        Apple,
        Cherry,
        Grapes,
        Lemon,
        Orange,
        Strawberry,
    }
}
