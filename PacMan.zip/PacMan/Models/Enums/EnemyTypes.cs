﻿namespace PacMan.Models.Enums
{
    public enum EnemyTypes
    {
        NotSet = 0,
        Blinky,
        Clyde,
        Inky,
        Pinky,
    }
}
