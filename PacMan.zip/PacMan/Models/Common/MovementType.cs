﻿namespace PacMan.Models.Common
{
    public enum MovementType
    {
        Up = 0,
        Down = 1, 
        Left = 2,
        Right = 3
    }
}